import numpy as np

def new_params(number: int) -> tuple:
    """
    Generate two square Numpy arrays with random integers.
    
    The range of random integers widens as the array size increases.
    
    Parameters:
    number (int): The size of the square arrays and the upper limit of
    their random values.
    
    Returns:
    tuple: A tuple containing two Numpy arrays.
    """
    
    # Create a random number generator with a random seed
    random_gen = np.random.default_rng()
    
    # Create two square arrays of number x number size
    # Their values should range from 0 to number
    params1 = random_gen.integers(low=0, high=number, size=(number, number))
    params2 = random_gen.integers(low=0, high=number, size=(number, number))
    
    return params1, params2

params1, params2 = new_params(5)
print(params1)
print(params2)