# SPDX-FileCopyrightText: 2024-present octakitten <raspberry2425@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "v0.5.0b7"
